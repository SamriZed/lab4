package lab4;

public class Member {

	public void borrowBook(Library library, Book title) {
		
		if (library.checkBook(title)){
			title.borrowBook();
			library.removeBook(title);
				}
				else {
					System.out.println("Book not available");
				}
	}
	public void returnBook(Library library, Book book) {
		library.addBook(book);
		System.out.println(book.getTitle()+" has been returned.");
	}
}
