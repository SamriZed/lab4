package lab4;

public class Mainbook {

			public static void main(String[] args) {
				Book book1 = new Book ("The Great Gatsby", " F. Scott Fitzgerald ", true);
				Book book2 = new Book ("1984", "George Orwell", true);
				Book book3 = new Book("Animal Farm", "George Orwell", true);
				Library l = new Library ();
				Member member = new Member();
				l.addBook(book1);
				l.addBook(book2);
				l.addBook(book3);
				l.removeBook(book3);
				l.displayBooks();
				l.searchBook("1984");
				member.borrowBook(l,book3);
				member.borrowBook(l, book2);
				member.returnBook(l, book2);
				l.displayBooks();
			}

		}


